package cs252.voip;

import java.io.*;
import java.net.*;
import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;


public class client extends Activity {
	
	static Socket connection;
	static final int DIALOG_SETTINGS_ID = 1;
	settings setting;
	static PrintWriter out = null;
    static BufferedReader in = null;
    public static final String PREFS_NAME = "voipPrefs";
    String uname;
    String dserver;
    
    int progress;
    
    static ListView lv1;
    static String lv_arr[] = {};
    static ArrayAdapter<String> adpt;
    
    static Context context;
    
    int delay = 5000;   // delay for 5 sec.
    int period = 1000;  // repeat every sec.
    Timer timer = new Timer();
    Button button;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setting = new settings(this);
        progress = 1;
        SharedPreferences settingsData = getSharedPreferences(PREFS_NAME, 0);
        uname = settingsData.getString("uname", "");
        dserver = settingsData.getString("dserver", "");
        
        context = this;
        
        setContentView(R.layout.main);
        button = (Button) findViewById(R.id.dial);
        lv1=(ListView)findViewById(R.id.userlist);
        // By using setAdpater method in listview we an add string array in list.
        adpt = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1 , lv_arr);
        lv1.setAdapter(adpt);
        
        if(uname.equals("")){
        	setting.username.setText(uname);
        	showSettings();
        	fetchList();
        }
        else{
        	String lres = login(uname);
        	if(lres.equals("Login failed!!!") || lres.equals("username not available")){
        		showSettings();
        		fetchList();
        	}
        	else{
        		fetchList();
        	}
        }
        lv1.setClickable(true);
        lv1.setOnItemClickListener(new AdapterView.OnItemClickListener() {

          //@Override
          public void onItemClick(AdapterView<?> arg0, View arg1, int position, long arg3) {

            Object o = lv1.getItemAtPosition(position);
            String connect = o.toString();
            Intent intent = new Intent(client.this, ringer.class);
            startActivity(intent);

            //Toast.makeText(client.this, connect, Toast.LENGTH_SHORT).show();
          }
        });

    }
    
    private class FetchListTask extends AsyncTask<String, String, Long> {
        protected Long doInBackground(String... urls) {
            long totalSize = 0;
            
            //totalSize += Downloader.downloadFile(urls[i]);
            timer.scheduleAtFixedRate(new TimerTask(){
            	public void run(){
	    					
	    					
            		//button.setText(button.getText().toString()+"-");
	    					
            		try{
            			connection = new Socket("128.10.2.16", 3456);
            			out = new PrintWriter(connection.getOutputStream(), true);
            			//while(i<5){
            			out.write("-2 \n");
            			out.flush();
            			in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            		}
            		catch(Exception e){
            			
            		}
            		//String response = ois.readUTF();
            		//}
            		
            		
            		//adpt.clear();
            		//Toast.makeText(client.this, "test", Toast.LENGTH_SHORT).show();
            		String arr[] = new String[10];
            		String list = "";
            		String msg = "";
            		int index = 0;
            		int c = 0;
            		try{
            			while(true){
            				c++;
            				list = in.readLine();
            				//Toast.makeText(client.this, list, Toast.LENGTH_SHORT).show();
            				//Thread.sleep(100);
            				//Toast.makeText(client.this, list, Toast.LENGTH_SHORT).show();
            				if(list.equals("-1 ")){
            					//Toast.makeText(client.this, "end", Toast.LENGTH_SHORT).show();
            					lv_arr = new String[index];
            					for(int i = 0; i < index; i++){
            						lv_arr[i] = arr[i];
            					}
            					index = 0;
            					int ptmp = progress++;
                        		publishProgress(ptmp+".");
            					/*adpt = new ArrayAdapter<String>(context,android.R.layout.simple_list_item_1 , lv_arr);
            					lv1.setAdapter(adpt);
            					
            					adpt.notifyDataSetChanged();*/
            				}
            				else{
            					//Toast.makeText(client.this, list, Toast.LENGTH_SHORT).show();
            					arr[index] = list;
            					msg += list;
            					index++;
            				}
            			}
            		} catch(Exception e){
            			
            			//Toast.makeText(client.this, "Error: "+connection.isInputShutdown(), Toast.LENGTH_SHORT).show();
            		}
            		
            		//Toast.makeText(client.this, "count: "+c+"\n"+msg, Toast.LENGTH_SHORT).show();
            	}
            }, delay, period);
            return totalSize;
        }

        protected void onProgressUpdate(String... progress) {
        	adpt = new ArrayAdapter<String>(context,android.R.layout.simple_list_item_1 , lv_arr);
			lv1.setAdapter(adpt);
			adpt.notifyDataSetChanged();
        }

        protected void onPostExecute(Long result) {
            //showDialog("Downloaded " + result + " bytes");
        }
    }

    
    protected void fetchList(){
    	new FetchListTask().execute("test");

    	//fetchList thread = new fetchList(this);
    	//thread.start();
    	/*new Thread(new Runnable() {
    		public void run() {
    			timer.scheduleAtFixedRate(new TimerTask(){
    				public void run(){
    					
    					
    					button.setText(button.getText().toString()+"-");
    					
    					try{
	    					connection = new Socket("128.10.2.16", 3456);
	    			    	out = new PrintWriter(connection.getOutputStream(), true);
	    			    	//while(i<5){
	    			    	out.write("-2 \n");
	    			    	out.flush();
	    			    	in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
    					}
    					catch(Exception e){
    						
    					}
    			    	//String response = ois.readUTF();
    			    	//}
    			    	
    			    	
    					//adpt.clear();
    	    			//Toast.makeText(client.this, "test", Toast.LENGTH_SHORT).show();
    			    	String arr[] = new String[10];
    			    	String list = "";
    			    	String msg = "";
    			    	int index = 0;
    			    	int c = 0;
    			    	try{
    				    	while(true){
    				    		c++;
    				    		list = in.readLine();
    				    		//Toast.makeText(client.this, list, Toast.LENGTH_SHORT).show();
    				    		//Thread.sleep(100);
    				    		//Toast.makeText(client.this, list, Toast.LENGTH_SHORT).show();
    				    		if(list.equals("-1 ")){
    				    			//Toast.makeText(client.this, "end", Toast.LENGTH_SHORT).show();
    				    			lv_arr = new String[index];
    				    			for(int i = 0; i < index; i++){
    				    				lv_arr[i] = arr[i];
    				    			}
    				    			index = 0;
    				    			
    				    			
    				    			adpt = new ArrayAdapter<String>(context,android.R.layout.simple_list_item_1 , lv_arr);
    				    			lv1.setAdapter(adpt);
    				    			
    				    			adpt.notifyDataSetChanged();
    				    		}
    				    		else{
    				    			//Toast.makeText(client.this, list, Toast.LENGTH_SHORT).show();
    				    			arr[index] = list;
    				    			msg += list;
    				    			index++;
    				    		}
    				    	}
    			    	} catch(Exception e){
    			    		
    			    		//Toast.makeText(client.this, "Error: "+connection.isInputShutdown(), Toast.LENGTH_SHORT).show();
    			    	}
    			    	//Toast.makeText(client.this, "count: "+c+"\n"+msg, Toast.LENGTH_SHORT).show();
    				}
    			}, delay, period);
    		}
    	}).start();*/
    }
    
    protected void ringer(){
    	
    }
    
    protected void showSettings(){
    	
		setting.show();
		setting.button.setOnClickListener(new OnClickListener() {
		    public void onClick(View v) {
		        // Perform action on clicks
		        Toast.makeText(client.this, "connecting...", Toast.LENGTH_SHORT).show();
		        String res = login(setting.username.getText().toString());
		        Toast.makeText(client.this, res, Toast.LENGTH_SHORT).show();
		        if(!res.equals("Login failed!!!") && !res.equals("username not available")){
		        	SharedPreferences settingsData = getSharedPreferences(PREFS_NAME, 0);
		            SharedPreferences.Editor editor = settingsData.edit();
		            editor.putString("uname", setting.username.getText().toString());
		            editor.commit();

		        	setting.dismiss();
		        	//fetchList();
		        }
		    }
		});
    }
    
    protected static String login( String username){
    	try{
	    	connection = new Socket("128.10.2.16", 3456);
	    	out = new PrintWriter(connection.getOutputStream(), true);
	    	username += " \n";
	    	//while(i<5){
	    	out.write(username);
	    	out.flush();
	    	//String response = ois.readUTF();
	    	//}
	    	
	    	in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	    	String response = "test";
	    	response = in.readLine();
	    	out.close();
	    	in.close();
	    	connection.close();
	    	//oos.close();
	    	//showToast();
	    	return response;
	    	
	    	
	    	//}
	    	//connection.close();
    	
    	}
    	catch (UnknownHostException e) {
    	     return("Unknown host: kq6py");
    	     //System.exit(1);
    	} 
    	catch  (IOException e) {
    	     return("Login failed!!!");
    	}
    }
}

